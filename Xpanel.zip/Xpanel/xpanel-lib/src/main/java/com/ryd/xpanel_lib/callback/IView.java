package com.ryd.xpanel_lib.callback;

public interface IView {
    void setCallback(ICallback callback);
}
